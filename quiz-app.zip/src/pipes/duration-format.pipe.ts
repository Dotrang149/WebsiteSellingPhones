// Create a pipe to format the duration in minutes to a human-readable format.
// The pipe should take a number as input and return a string.
// The pipe should format the number as follows:
// - If the number is less than 60, return the number followed by 'm'.
// - If the number is greater than or equal to 60, return the number divided by 60 followed by 'h'.

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'durationFormat'
})

export class DurationFormatPipe implements PipeTransform {
  transform(value: number): string {
    if (value < 60) {
      return value + 'm';
    } else {
      const hours = Math.floor(value / 60) + 'h';
      const minutes = value % 60 + 'm';
      return hours + (value % 60 ? '' + minutes : '');
    }
  }
}
