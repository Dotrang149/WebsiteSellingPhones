import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DurationFormatPipe } from './duration-format.pipe';
import { EnumDisplayPipe } from './enum-display.pipe';



@NgModule({
  declarations: [DurationFormatPipe, EnumDisplayPipe],
  exports: [DurationFormatPipe, EnumDisplayPipe],
})
export class PipeModule { }
