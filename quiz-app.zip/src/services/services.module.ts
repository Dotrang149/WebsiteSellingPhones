import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  AUTH_SERVICE_INJECTOR,
  QUESTION_SERVICE_INJECTOR,
  QUIZ_SERVICE_INJECTOR,
  ROLE_SERVICE_INJECTOR,
  USER_SERVICE_INJECTOR,
} from '../constants/injection-token.constant';
import { UserService } from './implementations/user.service';
import { RoleService } from './implementations/role.service';
import { QuizService } from './implementations/quiz.service';
import { QuestionService } from './implementations/question.service';

@NgModule({
  declarations: [],
  imports: [CommonModule],
  providers: [
    {
      provide: USER_SERVICE_INJECTOR,
      useClass: UserService,
    },
    {
      provide: ROLE_SERVICE_INJECTOR,
      useClass: RoleService,
    },
    {
      provide: QUIZ_SERVICE_INJECTOR,
      useClass: QuizService,
    },
    {
      provide: QUESTION_SERVICE_INJECTOR,
      useClass: QuestionService,
    },
  ],
})
export class ServicesModule {}
