import { Observable } from 'rxjs';
import { QuizCreateViewModel } from '../../view-models/quiz/quiz-create.view-model';
import { QuizEditViewModel } from '../../view-models/quiz/quiz-edit.view-model';
import { QuizViewModel } from '../../view-models/quiz/quiz.view-model';
import { QuizQuestionCreateViewModel } from '../../view-models/quiz/quiz-question-create.view-model';
import { QuizPrepareInfoViewModel } from '../../view-models/quiz/quiz-prepare-info.view-model';
import { QuizForTestViewModel } from '../../view-models/quiz/quiz-for-test.view-model';
import { TakeQuizViewModel } from '../../view-models/quiz/take-quiz.view-model';
import { QuizSubmissionViewModel } from '../../view-models/quiz/quiz-submission.view-model';
import { PrepareQuizViewModel } from '../../view-models/quiz/prepare-quiz.view-model';

/**
 * Represents a Quiz Service that provides methods for interacting with quizzes.
 */
export interface IQuizService {
  /**
   * Retrieves all quizzes.
   * @returns An Observable that emits an array of QuizViewModel.
   */
  getAll(): Observable<QuizViewModel[]>;

  /**
   * Retrieves a quiz by its ID.
   * @param id - The ID of the quiz.
   * @returns An Observable that emits a QuizViewModel.
   */
  getById(id: string): Observable<QuizViewModel>;

  /**
   * Creates a new quiz.
   * @param obj - The QuizCreateViewModel object representing the quiz to be created.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(obj: QuizCreateViewModel): Observable<boolean>;

  /**
   * Updates an existing quiz.
   * @param obj - The QuizEditViewModel object representing the updated quiz.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(obj: QuizEditViewModel): Observable<boolean>;

  /**
   * Deletes a quiz by its ID.
   * @param id - The ID of the quiz to be deleted.
   * @returns An Observable that emits the result of the deletion operation.
   */
  delete(id: string): Observable<boolean>;

  /**
   * Deletes a question from a quiz.
   * @param selectedId - The ID of the quiz.
   * @param selectedQuizQuestionId - The ID of the question to delete.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  deleteQuestionFromQuiz(
    selectedId: string,
    selectedQuizQuestionId: string
  ): Observable<boolean>;

  /**
   * Adds a question to a quiz.
   * @param obj - The QuizQuestionCreateViewModel object representing the question to add.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  addQuestionToQuiz(obj: QuizQuestionCreateViewModel): Observable<boolean>;

  /**
   * Prepares a quiz for a user.
   * @param data - The QuizPrepareInfoViewModel object representing the quiz to prepare.
   * @returns An Observable that emits a QuizPrepareInfoViewModel object.
   */
  prepareQuiz(data: PrepareQuizViewModel): Observable<QuizPrepareInfoViewModel>;

  /**
   * Retrieves a quiz for testing.
   * @param quizPrepareInfo - The QuizPrepareInfoViewModel object representing the quiz to test.
   * @returns An Observable that emits a QuizForTestViewModel object.
   */
  takeQuiz(
    takeQuizViewModel: TakeQuizViewModel
  ): Observable<QuizForTestViewModel>;

  /**
   * Submits a quiz.
   * @param quizSubmissionViewModel - The QuizSubmissionViewModel object representing the quiz to submit.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  submitQuiz(
    quizSubmissionViewModel: QuizSubmissionViewModel
  ): Observable<boolean>;
}
