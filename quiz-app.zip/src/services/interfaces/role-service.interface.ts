import { Observable } from 'rxjs';
import { RoleCreateViewModel } from '../../view-models/role/role-create.view-model';
import { RoleEditViewModel } from '../../view-models/role/role-edit.view-model';
import { RoleViewModel } from '../../view-models/role/role.view-model';

/**
 * Represents a Role Service that provides methods for interacting with rolezes.
 */
export interface IRoleService {
  /**
   * Retrieves all rolezes.
   * @returns An Observable that emits an array of RoleViewModel.
   */
  getAll(): Observable<RoleViewModel[]>;

  /**
   * Retrieves a role by its ID.
   * @param id - The ID of the role.
   * @returns An Observable that emits a RoleViewModel.
   */
  getById(id: string): Observable<RoleViewModel>;

  /**
   * Creates a new role.
   * @param obj - The RoleCreateViewModel object representing the role to be created.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(obj: RoleCreateViewModel): Observable<boolean>;

  /**
   * Updates an existing role.
   * @param obj - The RoleEditViewModel object representing the updated role.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(obj: RoleEditViewModel): Observable<boolean>;

  /**
   * Deletes a role by its ID.
   * @param id - The ID of the role to be deleted.
   * @returns An Observable that emits the result of the deletion operation.
   */
  delete(id: string): Observable<any>;
}
