import { Observable } from 'rxjs';
import { UserCreateViewModel } from '../../view-models/user/user-create.view-model';
import { UserEditViewModel } from '../../view-models/user/user-edit.view-model';
import { UserViewModel } from '../../view-models/user/user.view-model';

/**
 * Represents a User Service that provides methods for interacting with userzes.
 */
export interface IUserService {
  /**
   * Retrieves all userzes.
   * @returns An Observable that emits an array of UserViewModel.
   */
  getAll(): Observable<UserViewModel[]>;

  /**
   * Retrieves a user by its ID.
   * @param id - The ID of the user.
   * @returns An Observable that emits a UserViewModel.
   */
  getById(id: string): Observable<UserViewModel>;

  /**
   * Creates a new user.
   * @param obj - The UserCreateViewModel object representing the user to be created.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(obj: UserCreateViewModel): Observable<boolean>;

  /**
   * Updates an existing user.
   * @param obj - The UserEditViewModel object representing the updated user.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(obj: UserEditViewModel): Observable<boolean>;

  /**
   * Deletes a user by its ID.
   * @param id - The ID of the user to be deleted.
   * @returns An Observable that emits the result of the deletion operation.
   */
  delete(id: string): Observable<any>;
}
