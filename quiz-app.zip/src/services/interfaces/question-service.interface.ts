import { Observable } from 'rxjs';
import { QuestionCreateViewModel } from '../../view-models/question/question-create.view-model';
import { QuestionEditViewModel } from '../../view-models/question/question-edit.view-model';
import { QuestionViewModel } from '../../view-models/question/question.view-model';
import { AnswerViewModel } from '../../view-models/question/answer.view-model';
import { AnswerCreateViewModel } from '../../view-models/question/answer-create.view-model';
import { AnswerEditViewModel } from '../../view-models/question/answer-edit.view-model';

/**
 * Represents a Question Service that provides methods for interacting with questionzes.
 */
export interface IQuestionService {
  /**
   * Retrieves all questionzes.
   * @returns An Observable that emits an array of QuestionViewModel.
   */
  getAll(): Observable<QuestionViewModel[]>;

  /**
   * Retrieves questions by quiz ID.
   * @param id - The ID of the quiz.
   * @returns An Observable that emits an array of QuestionViewModel.
   */
  getQuestionsByQuizId(id: string): Observable<QuestionViewModel[]>;

  /**
   * Retrieves answers by question ID.
   * @param selectedId - The ID of the question.
   * @returns An Observable that emits an AnswerViewModel.
   */
  getAnswersByQuestionId(selectedId: string): Observable<AnswerViewModel>;

  /**
   * Retrieves an answer by its ID.
   * @param selectedId - The ID of the answer.
   * @returns An Observable that emits an AnswerViewModel.
   */
  getAnswerById(selectedId: string): Observable<AnswerViewModel>;

  /**
   * Retrieves a question by its ID.
   * @param id - The ID of the question.
   * @returns An Observable that emits a QuestionViewModel.
   */
  getById(id: string): Observable<QuestionViewModel>;

  /**
   * Creates a new question.
   * @param obj - The QuestionCreateViewModel object representing the question to be created.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(obj: QuestionCreateViewModel): Observable<boolean>;

  /**
   * Adds an answer to a question.
   * @param obj - The AnswerCreateViewModel object representing the answer to add.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  addAnswerToQuestion(obj: AnswerCreateViewModel): Observable<boolean>;

  /**
   * Updates an answer to a question.
   * @param obj - The AnswerCreateViewModel object representing the answer to update.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  updateAnswerToQuestion(obj: AnswerEditViewModel): Observable<boolean>;

  /**
   * Updates an existing question.
   * @param obj - The QuestionEditViewModel object representing the updated question.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(obj: QuestionEditViewModel): Observable<boolean>;

  /**
   * Deletes a question by its ID.
   * @param id - The ID of the question to be deleted.
   * @returns An Observable that emits the result of the deletion operation.
   */
  delete(id: string): Observable<boolean>;

  /**
   * Deletes an answer by its ID.
   * @param answerId - The ID of the answer to be deleted.
   * @returns An Observable that emits the result of the deletion operation.
   */
  deleteAnswer(answerId: string, questionId: string): Observable<boolean>;
}
