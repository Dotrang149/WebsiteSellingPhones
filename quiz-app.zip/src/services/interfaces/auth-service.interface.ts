import { LoginResponseViewModel } from '../../view-models/auth/login-response.view-model';
import { LoginViewModel } from '../../view-models/auth/login.view-model';
import { UserCreateViewModel } from '../../view-models/user/user-create.view-model';
import { UserViewModel } from '../../view-models/user/user.view-model';

export interface IAuthService {
  login(
    returnUrl: string,
    model: LoginViewModel
  ): Promise<LoginResponseViewModel | undefined>;

  register(
    userCreateViewModel: UserCreateViewModel
  ): Promise<LoginResponseViewModel | undefined>;

  isAuthenticated(): boolean;

  getAccessToken(): string;

  logout(): boolean;

  getCurrentUser(): UserViewModel | undefined;

  isManager(): boolean;
}
