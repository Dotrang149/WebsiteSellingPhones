import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IUserService } from '../interfaces/user-service.interface';
import { UserViewModel } from '../../view-models/user/user.view-model';
import { UserCreateViewModel } from '../../view-models/user/user-create.view-model';
import { UserEditViewModel } from '../../view-models/user/user-edit.view-model';

@Injectable()
export class UserService implements IUserService {
  /**
   * The base URL for the API endpoint.
   */
  public apiUrl = 'http://localhost:5195/api/v1.0/users';

  /**
   * Constructs a new instance of the UserService class.
   * @param httpClient - The HttpClient instance used for making HTTP requests.
   */
  public constructor(protected httpClient: HttpClient) {}

  /**
   * Retrieves all userzes.
   * @returns An Observable that emits an array of UserViewModel objects.
   */
  getAll(): Observable<UserViewModel[]> {
    return this.httpClient.get<UserViewModel[]>(this.apiUrl);
  }

  /**
   * Retrieves a user by its ID.
   * @param id - The ID of the user to retrieve.
   * @returns An Observable that emits a UserViewModel object.
   */
  getById(id: any): Observable<UserViewModel> {
    return this.httpClient.get<UserViewModel>(`${this.apiUrl}/${id}`);
  }

  /**
   * Creates a new user.
   * @param queryObj - The UserCreateViewModel object representing the user to create.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(queryObj: UserCreateViewModel): Observable<boolean> {
    return this.httpClient.post<boolean>(this.apiUrl, queryObj);
  }

  /**
   * Updates an existing user.
   * @param queryObj - The UserEditViewModel object representing the user to update.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(queryObj: UserEditViewModel): Observable<boolean> {
    return this.httpClient.put<boolean>(
      this.apiUrl + '/' + queryObj.id,
      queryObj
    );
  }

  /**
   * Deletes a user by its ID.
   * @param id - The ID of the user to delete.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  delete(id: string): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${this.apiUrl}/${id}`);
  }
}
