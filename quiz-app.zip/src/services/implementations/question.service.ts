import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IQuestionService } from '../interfaces/question-service.interface';
import { QuestionViewModel } from '../../view-models/question/question.view-model';
import { QuestionCreateViewModel } from '../../view-models/question/question-create.view-model';
import { QuestionEditViewModel } from '../../view-models/question/question-edit.view-model';
import { AnswerViewModel } from '../../view-models/question/answer.view-model';
import { AnswerCreateViewModel } from '../../view-models/question/answer-create.view-model';
import { AnswerEditViewModel } from '../../view-models/question/answer-edit.view-model';

@Injectable()
export class QuestionService implements IQuestionService {
  /**
   * The base URL for the API endpoint.
   */
  public apiUrl = 'http://localhost:5195/api/v1.0/questions';

  /**
   * Constructs a new instance of the QuestionService class.
   * @param httpClient - The HttpClient instance used for making HTTP requests.
   */
  public constructor(protected httpClient: HttpClient) {}

  /**
   * Updates an answer to a question.
   * @param obj - The AnswerEditViewModel object representing the answer to update.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  updateAnswerToQuestion(obj: AnswerEditViewModel): Observable<boolean> {
    return this.httpClient.put<boolean>(
      `${this.apiUrl}/updateAnswerToQuestion`,
      obj
    );
  }

  /**
   * Adds an answer to a question.
   * @param obj - The AnswerCreateViewModel object representing the answer to add.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  addAnswerToQuestion(obj: AnswerCreateViewModel): Observable<boolean> {
    return this.httpClient.post<boolean>(
      `${this.apiUrl}/addAnswerToQuestion`,
      obj
    );
  }

  /**
   * Retrieves answers by question ID.
   * @param questionId - The ID of the question.
   * @returns An Observable that emits an AnswerViewModel object.
   */
  getAnswersByQuestionId(questionId: string): Observable<AnswerViewModel> {
    return this.httpClient.get<AnswerViewModel>(
      `${this.apiUrl}/getAnswersByQuestionId/${questionId}`
    );
  }

  /**
   * Retrieves answers by ID.
   * @param questionId - The ID of the answer.
   * @returns An Observable that emits an AnswerViewModel object.
   */
  getAnswerById(answerId: string): Observable<AnswerViewModel> {
    return this.httpClient.get<AnswerViewModel>(
      `${this.apiUrl}/answers/${answerId}`
    );
  }

  /**
   * Retrieves all questionzes.
   * @returns An Observable that emits an array of QuestionViewModel objects.
   */
  getAll(): Observable<QuestionViewModel[]> {
    return this.httpClient.get<QuestionViewModel[]>(this.apiUrl);
  }

  /**
   * Retrieves questions by quiz ID.
   * @param id - The ID of the quiz.
   * @returns An Observable that emits an array of QuestionViewModel.
   */
  getQuestionsByQuizId(id: string): Observable<QuestionViewModel[]> {
    return this.httpClient.get<QuestionViewModel[]>(
      this.apiUrl + '/getQuestionsByQuizId/' + id
    );
  }

  /**
   * Retrieves a question by its ID.
   * @param id - The ID of the question to retrieve.
   * @returns An Observable that emits a QuestionViewModel object.
   */
  getById(id: any): Observable<QuestionViewModel> {
    return this.httpClient.get<QuestionViewModel>(`${this.apiUrl}/${id}`);
  }

  /**
   * Creates a new question.
   * @param queryObj - The QuestionCreateViewModel object representing the question to create.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(queryObj: QuestionCreateViewModel): Observable<boolean> {
    return this.httpClient.post<boolean>(this.apiUrl, queryObj);
  }

  /**
   * Updates an existing question.
   * @param queryObj - The QuestionEditViewModel object representing the question to update.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(queryObj: QuestionEditViewModel): Observable<boolean> {
    return this.httpClient.put<boolean>(
      this.apiUrl + '/' + queryObj.id,
      queryObj
    );
  }

  /**
   * Deletes a question by its ID.
   * @param id - The ID of the question to delete.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  delete(id: string): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${this.apiUrl}/${id}`);
  }

  /**
   * Deletes an answer by its ID.
   * @param answerId - The ID of the answer to be deleted.
   * @returns An Observable that emits the result of the deletion operation.
   */
  deleteAnswer(answerId: string, questionId: string): Observable<boolean> {
    return this.httpClient.delete<boolean>(
      `${this.apiUrl}/${questionId}/answers/${answerId}`
    );
  }
}
