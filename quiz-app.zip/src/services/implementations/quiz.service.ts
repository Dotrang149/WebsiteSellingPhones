import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IQuizService } from '../interfaces/quiz-service.interface';
import { QuizViewModel } from '../../view-models/quiz/quiz.view-model';
import { QuizCreateViewModel } from '../../view-models/quiz/quiz-create.view-model';
import { QuizEditViewModel } from '../../view-models/quiz/quiz-edit.view-model';
import { QuizQuestionCreateViewModel } from '../../view-models/quiz/quiz-question-create.view-model';
import { QuizPrepareInfoViewModel } from '../../view-models/quiz/quiz-prepare-info.view-model';
import { QuizForTestViewModel } from '../../view-models/quiz/quiz-for-test.view-model';
import { TakeQuizViewModel } from '../../view-models/quiz/take-quiz.view-model';
import { QuizSubmissionViewModel } from '../../view-models/quiz/quiz-submission.view-model';
import { PrepareQuizViewModel } from '../../view-models/quiz/prepare-quiz.view-model';

@Injectable()
export class QuizService implements IQuizService {
  /**
   * The base URL for the API endpoint.
   */
  public apiUrl = 'http://localhost:5195/api/v1.0/quizzes';

  /**
   * Constructs a new instance of the QuizService class.
   * @param httpClient - The HttpClient instance used for making HTTP requests.
   */
  public constructor(protected httpClient: HttpClient) {}

  /**
   * Submits a quiz for grading.
   * @param quizSubmissionViewModel - The QuizSubmissionViewModel object representing the quiz to submit.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  submitQuiz(
    quizSubmissionViewModel: QuizSubmissionViewModel
  ): Observable<boolean> {
    return this.httpClient.post<boolean>(
      `${this.apiUrl}/submitQuiz`,
      quizSubmissionViewModel
    );
  }

  /**
   * Prepares a quiz for a user.
   * @param data - The data object representing the quiz to prepare.
   * @returns An Observable that emits a QuizPrepareInfoViewModel object.
   */
  takeQuiz(
    quizPrepareInfo: TakeQuizViewModel
  ): Observable<QuizForTestViewModel> {
    return this.httpClient.post<QuizForTestViewModel>(
      `${this.apiUrl}/takeQuiz`,
      quizPrepareInfo
    );
  }

  /**
   * Prepares a quiz for a user.
   * @param data - The data object representing the quiz to prepare.
   * @returns An Observable that emits a QuizPrepareInfoViewModel object.
   */
  prepareQuiz(data: PrepareQuizViewModel): Observable<QuizPrepareInfoViewModel> {
    return this.httpClient.post<QuizPrepareInfoViewModel>(
      `${this.apiUrl}/prepareQuizForUser`,
      data
    );
  }

  /**
   * Adds a question to a quiz.
   * @param obj - The QuizQuestionCreateViewModel object representing the question to add.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  addQuestionToQuiz(obj: QuizQuestionCreateViewModel): Observable<boolean> {
    return this.httpClient.post<boolean>(
      `${this.apiUrl}/addQuestionToQuiz`,
      obj
    );
  }

  /**
   * Retrieves all quizzes.
   * @returns An Observable that emits an array of QuizViewModel objects.
   */
  getAll(): Observable<QuizViewModel[]> {
    return this.httpClient.get<QuizViewModel[]>(this.apiUrl);
  }

  /**
   * Retrieves a quiz by its ID.
   * @param id - The ID of the quiz to retrieve.
   * @returns An Observable that emits a QuizViewModel object.
   */
  getById(id: any): Observable<QuizViewModel> {
    return this.httpClient.get<QuizViewModel>(`${this.apiUrl}/${id}`);
  }

  /**
   * Creates a new quiz.
   * @param queryObj - The QuizCreateViewModel object representing the quiz to create.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(queryObj: QuizCreateViewModel): Observable<boolean> {
    return this.httpClient.post<boolean>(this.apiUrl, queryObj);
  }

  /**
   * Updates an existing quiz.
   * @param queryObj - The QuizEditViewModel object representing the quiz to update.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(queryObj: QuizEditViewModel): Observable<boolean> {
    return this.httpClient.put<boolean>(
      this.apiUrl + '/' + queryObj.id,
      queryObj
    );
  }

  /**
   * Deletes a quiz by its ID.
   * @param id - The ID of the quiz to delete.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  delete(id: string): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${this.apiUrl}/${id}`);
  }

  /**
   * Deletes a question from a quiz.
   * @param selectedId - The ID of the quiz.
   * @param selectedQuizQuestionId - The ID of the question to delete.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  deleteQuestionFromQuiz(
    selectedId: string,
    selectedQuizQuestionId: string
  ): Observable<boolean> {
    return this.httpClient.delete<boolean>(
      `${this.apiUrl}/${selectedId}/questions/${selectedQuizQuestionId}`
    );
  }
}
