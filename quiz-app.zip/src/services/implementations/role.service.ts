import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IRoleService } from '../interfaces/role-service.interface';
import { RoleViewModel } from '../../view-models/role/role.view-model';
import { RoleCreateViewModel } from '../../view-models/role/role-create.view-model';
import { RoleEditViewModel } from '../../view-models/role/role-edit.view-model';

@Injectable()
export class RoleService implements IRoleService {
  /**
   * The base URL for the API endpoint.
   */
  public apiUrl = 'http://localhost:5195/api/v1.0/roles';

  /**
   * Constructs a new instance of the RoleService class.
   * @param httpClient - The HttpClient instance used for making HTTP requests.
   */
  public constructor(protected httpClient: HttpClient) {}

  /**
   * Retrieves all rolezes.
   * @returns An Observable that emits an array of RoleViewModel objects.
   */
  getAll(): Observable<RoleViewModel[]> {
    return this.httpClient.get<RoleViewModel[]>(this.apiUrl);
  }

  /**
   * Retrieves a role by its ID.
   * @param id - The ID of the role to retrieve.
   * @returns An Observable that emits a RoleViewModel object.
   */
  getById(id: any): Observable<RoleViewModel> {
    return this.httpClient.get<RoleViewModel>(`${this.apiUrl}/${id}`);
  }

  /**
   * Creates a new role.
   * @param queryObj - The RoleCreateViewModel object representing the role to create.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  create(queryObj: RoleCreateViewModel): Observable<boolean> {
    return this.httpClient.post<boolean>(this.apiUrl, queryObj);
  }

  /**
   * Updates an existing role.
   * @param queryObj - The RoleEditViewModel object representing the role to update.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  update(queryObj: RoleEditViewModel): Observable<boolean> {
    return this.httpClient.put<boolean>(
      this.apiUrl + '/' + queryObj.id,
      queryObj
    );
  }

  /**
   * Deletes a role by its ID.
   * @param id - The ID of the role to delete.
   * @returns An Observable that emits a boolean indicating the success of the operation.
   */
  delete(id: string): Observable<boolean> {
    return this.httpClient.delete<boolean>(`${this.apiUrl}/${id}`);
  }
}
