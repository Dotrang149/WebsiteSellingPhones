import { Component, Inject, OnInit } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { IAuthService } from '../../../services/interfaces/auth-service.interface';
import { AuthService } from '../../../services/implementations/auth.service';
import { DialogComponent } from '../../shared/dialog/dialog.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, RouterModule, DialogComponent, CommonModule],
  providers: [{ provide: 'AUTH_SERVICE_INJECTOR', useClass: AuthService }],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit {
  public loginForm!: FormGroup;
  private isAuthenticated: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  constructor(
    @Inject('AUTH_SERVICE_INJECTOR') private authService: IAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isAuthenticated = this.authService.isAuthenticated();

    if (this.isAuthenticated) {
      this.router.navigate(['/']);
    }

    this.loginForm = new FormGroup({
      username: new FormControl(''),
      password: new FormControl(''),
    });
  }

  public login(): void {
    if (this.loginForm.valid) {
      this.authService.login('/', this.loginForm.value).then((response: any) => {
        if (response) {
          if (response.error) {
            this.dialogTitle = 'Login Failed';
            this.dialogMessage = response.error.detail;
            this.isShowDialog = true;
          } else {
            window.location.href = '/';
          }
        }
      });
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
