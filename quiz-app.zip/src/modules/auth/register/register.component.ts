import { Component, Inject } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { IAuthService } from '../../../services/interfaces/auth-service.interface';
import { AUTH_SERVICE_INJECTOR } from '../../../constants/injection-token.constant';
import { DialogComponent } from '../../shared/dialog/dialog.component';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, RouterModule, DialogComponent],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
})
export class RegisterComponent {
  public registerForm!: FormGroup;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  constructor(
    @Inject(AUTH_SERVICE_INJECTOR) private authService: IAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.registerForm = new FormGroup({
      firstName: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(50),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(50),
      ]),
      username: new FormControl('', [
        Validators.required,
        Validators.minLength(3),
        Validators.maxLength(50),
      ]),
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
      ]),
      confirmPassword: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
      ]),
      phoneNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(15),
      ]),
      dateOfBirth: new FormControl('', [Validators.required]),
    });
  }

  public register(): void {
    if (this.registerForm.valid) {
      this.authService
        .register(this.registerForm.value)
        .then((response: any) => {
          if (response) {
            if (response.error) {
              // Show error message
              this.dialogTitle = 'Register Error';
              this.dialogMessage = response.error;
              this.isShowDialog = true;
            } else {
              window.location.href = '/';
            }
          }
        })
        .catch((error) => {
          // Show error message
          this.dialogTitle = 'Register Error';
          this.dialogMessage = 'Error while saving data';
          this.isShowDialog = true;
        });
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
