import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { provideClientHydration } from '@angular/platform-browser';
import {
  provideHttpClient,
  withFetch,
  withInterceptors,
} from '@angular/common/http';
import {
  AUTH_SERVICE_INJECTOR,
  USER_SERVICE_INJECTOR,
} from '../constants/injection-token.constant';
import { UserService } from '../services/implementations/user.service';
import { authInterceptor } from '../interceptors/auth.interceptor';
import { AuthService } from '../services/implementations/auth.service';
import { AuthenticatedUserGuard } from '../guards/authenticated-user.guard';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideClientHydration(),
    provideHttpClient(withInterceptors([authInterceptor]), withFetch()),
    importProvidersFrom(AuthenticatedUserGuard),
    {
      provide: USER_SERVICE_INJECTOR,
      useClass: UserService,
    },
    {
      provide: AUTH_SERVICE_INJECTOR,
      useClass: AuthService,
    },
  ],
};
