import { Component, Inject, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { QuizPrepareInfoViewModel } from '../../../view-models/quiz/quiz-prepare-info.view-model';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CommonModule } from '@angular/common';
import { faArrowRotateLeft, faPlay } from '@fortawesome/free-solid-svg-icons';
import { IQuizService } from '../../../services/interfaces/quiz-service.interface';
import { QUIZ_SERVICE_INJECTOR } from '../../../constants/injection-token.constant';
import { ServicesModule } from '../../../services/services.module';
import { TakeQuizViewModel } from '../../../view-models/quiz/take-quiz.view-model';
import { QuizForTestViewModel } from '../../../view-models/quiz/quiz-for-test.view-model';
import { QuizTestComponent } from './quiz-test/quiz-test.component';

@Component({
  selector: 'app-start-quiz',
  standalone: true,
  imports: [
    RouterModule,
    FontAwesomeModule,
    CommonModule,
    ServicesModule,
    QuizTestComponent,
  ],
  templateUrl: './start-quiz.component.html',
  styleUrl: './start-quiz.component.css',
})
export class StartQuizComponent implements OnInit {
  public quizPrepareInfo!: QuizPrepareInfoViewModel;

  public faArrowRotateLeft = faArrowRotateLeft;
  public faPlay = faPlay;
  public isShowQuizTest: boolean = false;
  public quizForTestModel!: QuizForTestViewModel;

  constructor(
    @Inject(QUIZ_SERVICE_INJECTOR) private quizService: IQuizService,
    private router: Router
  ) {
    const navigation = this.router.getCurrentNavigation();
    if (navigation && navigation.extras.state) {
      this.quizPrepareInfo = navigation.extras.state['data'];
    } else {
      this.router.navigateByUrl('/quizzes');
    }
  }

  ngOnInit(): void {}

  public takeQuiz(): void {
    const takeQuizViewModel: TakeQuizViewModel = {
      quizId: this.quizPrepareInfo.id,
      userId: this.quizPrepareInfo.user.id,
      quizCode: this.quizPrepareInfo.quizCode,
    };

    this.quizService.takeQuiz(takeQuizViewModel).subscribe((res: any) => {
      if (res) {
        this.quizForTestModel = res;
        this.isShowQuizTest = true;
      }
    });
  }

  public onSubmitted(): void {
    this.isShowQuizTest = false;
  }
}
