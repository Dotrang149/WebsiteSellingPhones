import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Inject, Input, OnInit, Output } from '@angular/core';
import { DialogComponent } from '../../../shared/dialog/dialog.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { faArrowRotateLeft, faSave } from '@fortawesome/free-solid-svg-icons';
import { AUTH_SERVICE_INJECTOR, QUIZ_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { IQuizService } from '../../../../services/interfaces/quiz-service.interface';
import { QuizSubmissionViewModel, UserAnswerSubmissionViewModel } from '../../../../view-models/quiz/quiz-submission.view-model';
import { QuizForTestViewModel } from '../../../../view-models/quiz/quiz-for-test.view-model';
import { QuestionType } from '../../../../enums/question-type.enum';
import { IAuthService } from '../../../../services/interfaces/auth-service.interface';

@Component({
  selector: 'app-quiz-test',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FontAwesomeModule,
    DialogComponent,
  ],
  templateUrl: './quiz-test.component.html',
  styleUrl: './quiz-test.component.css',
})
export class QuizTestComponent implements OnInit {
  public QuestionType = QuestionType;
  @Input() public quiz!: QuizForTestViewModel;
  @Output() public submit: EventEmitter<any> = new EventEmitter();

  public faArrowRotateLeft = faArrowRotateLeft;
  public faSave = faSave;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  constructor(
    @Inject(QUIZ_SERVICE_INJECTOR) private quizService: IQuizService,
    @Inject(AUTH_SERVICE_INJECTOR) private authService: IAuthService,
  ) {}

  ngOnInit(): void {
    this.createForm();
  }

  private createForm(): void {
    this.formGroup = new FormGroup({});

    this.quiz.questions.forEach((question: any) => {
      this.formGroup.addControl(question.id, new FormControl(''));
    });
  }

  public onSelectAnswer(questionId: string, answer: any): void {
    // get form control
    const formControl = this.formGroup.get(questionId);
    if (formControl) {
      formControl.setValue(answer.id);
    }
  }

  onCancel(): void {
    this.isShowDialog = true;

    this.dialogTitle = 'Cancel Quiz';
    this.dialogMessage =
      'Are you sure you want to cancel the quiz? Click Ok to submit or Cancel to return.';
  }

  public onConfirmCancel(): void {
    this.isShowDialog = false;
  }

  public onConfirmSubmit(): void {
    this.isShowDialog = false;
    this.submitQuiz();
  }

  public onSubmit(): void {
    this.isShowDialog = true;

    this.dialogTitle = 'Submit Quiz';
    this.dialogMessage =
      'Are you sure you want to submit the quiz? Click Ok to submit or Cancel to return.';
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }

  public onOkDialog(): void {
    this.isShowDialog = false;
    this.submitQuiz();
  }

  private submitQuiz(): void {
    const userId = this.authService.getCurrentUser()?.id;
    const formData: QuizSubmissionViewModel = {
      quizId: this.quiz.id,
      userId: userId ? userId : '',
      quizCode: this.quiz.quizCode,
      answers: this.quiz.questions.map((question: any) => {
        const value: UserAnswerSubmissionViewModel = {
          questionId: question.id,
          answerId: question.answer.id,
        };
        return value;
      }),
    };

    this.quizService.submitQuiz(formData).subscribe((data) => {
      if (data) {
        this.submit.emit(data);
      } else {
        // Show error message
        this.dialogTitle = 'Error';
        this.dialogMessage = 'Error while saving data';
        this.isShowDialog = true;
      }
    });
  }
}
