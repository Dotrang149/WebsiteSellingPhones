import { Component, Inject, OnInit } from '@angular/core';
import { v4 as uuidv4 } from 'uuid';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { QuizCardComponent } from '../../shared/quiz-card/quiz-card.component';
import { CommonModule, UpperCasePipe } from '@angular/common';
import { IQuizService } from '../../../services/interfaces/quiz-service.interface';
import {
  AUTH_SERVICE_INJECTOR,
  QUIZ_SERVICE_INJECTOR,
} from '../../../constants/injection-token.constant';
import { IAuthService } from '../../../services/interfaces/auth-service.interface';
import { ServicesModule } from '../../../services/services.module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-quizzes',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    FormsModule,
    QuizCardComponent,
    UpperCasePipe,
    CommonModule,
    ServicesModule,
  ],
  templateUrl: './quizzes.component.html',
  styleUrl: './quizzes.component.css',
})
export class QuizzesComponent implements OnInit {
  public takeQuizForm: FormGroup;

  public quizCode: FormControl = new FormControl('');

  public title: string = 'Home Page';
  public isAuthenticated: boolean = false;

  public quizzes: any[] = [];

  constructor(
    @Inject(QUIZ_SERVICE_INJECTOR)
    protected quizService: IQuizService,
    @Inject(AUTH_SERVICE_INJECTOR) private authService: IAuthService,
    private router: Router
  ) {
    this.takeQuizForm = new FormGroup({
      quizCode: new FormControl(''),
    });
  }

  ngOnInit(): void {
    this.isAuthenticated = this.authService.isAuthenticated();
    this.getData();
  }

  public getData() {
    this.quizService.getAll().subscribe((data) => {
      this.quizzes = data;
    });
  }

  public onTakeQuiz(): void {
    if (this.isAuthenticated) {
      const formData = Object.assign({}, this.takeQuizForm.value, {
        userId: this.authService.getCurrentUser()?.id,
        quizId: null,
      });

      this.quizService.prepareQuiz(formData).subscribe((res: any) => {
        // Redirect to start quiz page and pass res to the page
        this.router.navigateByUrl('/start-quiz', { state: { data: res } });
      });
    } else {
      this.router.navigateByUrl('/auth/login');
    }
  }
}
