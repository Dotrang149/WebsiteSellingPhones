import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuizCardComponent } from '../../shared/quiz-card/quiz-card.component';
import { ServicesModule } from '../../../services/services.module';
import {
  AUTH_SERVICE_INJECTOR,
  QUIZ_SERVICE_INJECTOR,
} from '../../../constants/injection-token.constant';
import { IQuizService } from '../../../services/interfaces/quiz-service.interface';
import { IAuthService } from '../../../services/interfaces/auth-service.interface';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, QuizCardComponent, ServicesModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent implements OnInit {
  public title: string = 'Home Page';

  public quizzes: any[] = [];

  public constructor(
    @Inject(QUIZ_SERVICE_INJECTOR)
    protected quizService: IQuizService,
    @Inject(AUTH_SERVICE_INJECTOR) private authService: IAuthService
  ) {}

  ngOnInit(): void {
    this.getData();
  }

  private getData() {
    this.quizService.getAll().subscribe((data) => {
      this.quizzes = data;
    });
  }

  public goToQuiz(): void {
    // Scroll to quizzes section with id = quizzes
    const element = document.getElementById('quizzes');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }
}
