import { Routes } from '@angular/router';
import { AuthenticationLayoutComponent } from './shared/authentication-layout/authentication-layout.component';
import { CustomerLayoutComponent } from './shared/customer-layout/customer-layout.component';
import { ManagerLayoutComponent } from './shared/manager-layout/manager-layout.component';
import { AuthenticatedUserGuard } from '../guards/authenticated-user.guard';
import { Error403Component } from './shared/error-403/error-403.component';

export const routes: Routes = [
  {
    path: 'error',
    component: CustomerLayoutComponent,
    children: [
      {
        path: '403',
        component: Error403Component,
      },
    ],
  },
  {
    path: 'manager',
    component: ManagerLayoutComponent,
    canActivate: [AuthenticatedUserGuard],
    loadChildren: () =>
      import('./manager/manager.module').then((m) => m.ManagerModule),
  },
  {
    path: 'auth',
    component: AuthenticationLayoutComponent,
    loadChildren: () => import('./auth/auth.module').then((m) => m.AuthModule),
  },
  {
    path: '',
    component: CustomerLayoutComponent,
    loadChildren: () =>
      import('./customer/customer.module').then((m) => m.CustomerModule),
  },
];
