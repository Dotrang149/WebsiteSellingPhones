import { CommonModule } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { faEdit, faPlus, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { RoleDetailsComponent } from '../role-details/role-details.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { IRoleService } from '../../../../services/interfaces/role-service.interface';
import { ROLE_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { ServicesModule } from '../../../../services/services.module';
import { DialogComponent } from '../../../shared/dialog/dialog.component';

@Component({
  selector: 'app-role-list',
  standalone: true,
  imports: [
    CommonModule,
    RoleDetailsComponent,
    FontAwesomeModule,
    ServicesModule,
    DialogComponent,
  ],
  templateUrl: './role-list.component.html',
  styleUrl: './role-list.component.css',
})
export class RoleListComponent {
  public faEdit = faEdit;
  public faTrashCan = faTrashCan;
  public faPlus = faPlus;

  public title: string = 'Role List';
  public selectedId: string = '';
  public isShowDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public roles: any[] = [];

  constructor(
    @Inject(ROLE_SERVICE_INJECTOR) private roleService: IRoleService
  ) {}

  ngOnInit(): void {
    this.getData();
  }

  private getData() {
    // Get data from service
    this.roleService.getAll().subscribe((data) => {
      this.roles = data;
    });
  }

  public delete(id: string): void {
    this.roleService.delete(id).subscribe((data) => {
      if (data) {
        this.roles = this.roles.filter((role) => role.id !== id);
      } else {
        // Show error message
        this.dialogTitle = 'Error';
        this.dialogMessage = 'Error while saving data';
        this.isShowDialog = true;
      }
    });
  }

  public edit(id: string): void {
    this.onCancelDetails();
    this.selectedId = id;
    this.isShowDetails = true;
  }

  public add(): void {
    this.onCancelDetails();
    this.selectedId = '';
    this.isShowDetails = true;
  }

  /**
   * on cancel details
   */
  public onCancelDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
  }

  /**
   * on save details
   */
  public onSaveDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
    this.getData();
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
