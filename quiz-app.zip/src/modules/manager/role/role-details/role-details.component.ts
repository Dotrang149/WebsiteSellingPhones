import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faArrowRotateLeft, faSave } from '@fortawesome/free-solid-svg-icons';
import { ROLE_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { IRoleService } from '../../../../services/interfaces/role-service.interface';
import { DialogComponent } from '../../../shared/dialog/dialog.component';

@Component({
  selector: 'app-role-details',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    FontAwesomeModule,
    FormsModule,
    CommonModule,
    DialogComponent,
  ],
  templateUrl: './role-details.component.html',
  styleUrl: './role-details.component.css',
})
export class RoleDetailsComponent implements OnInit {
  private _selectedId!: string;
  @Input() public set selectedId(data: string) {
    this._selectedId = data;

    if (data) {
      this.getData();
    } else {
      this.formGroup?.reset();
    }
  }

  public get selectedId(): string {
    return this._selectedId;
  }

  @Output() cancelForm: EventEmitter<any> = new EventEmitter();
  @Output() saveForm: EventEmitter<any> = new EventEmitter();

  public faSave = faSave;
  public faArrowRotateLeft = faArrowRotateLeft;

  public selectedQuizQuestionId: string = '';
  public isShowQuizQuestionList: boolean = false;
  public isShowQuizQuestionDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  constructor(
    @Inject(ROLE_SERVICE_INJECTOR) private roleService: IRoleService
  ) {}

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      name: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      description: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      isActive: new FormControl(''),
    });
  }

  private getData() {
    this.roleService.getById(this.selectedId).subscribe((data) => {
      this.formGroup.patchValue(data);
    });
  }

  /**
   * cancel form
   */
  public cancel() {
    this.cancelForm.emit(true);
  }

  /**
   * save form
   */

  public save() {
    if (this.formGroup.valid) {
      if (this.selectedId === '') {
        this.roleService.create(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Create Role Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      } else {
        this.formGroup.addControl('id', new FormControl(this.selectedId));
        this.roleService.update(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Update Role Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      }
    } else {
      // show error
      this.dialogTitle = 'Validation Error';
      this.dialogMessage = 'Please fill all required fields';
      this.isShowDialog = true;
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
