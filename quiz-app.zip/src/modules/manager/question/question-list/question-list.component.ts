import { Component, Inject } from '@angular/core';
import { faEdit, faPlus, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { QuestionType } from '../../../../enums/question-type.enum';
import { CommonModule } from '@angular/common';
import { QuestionDetailsComponent } from '../question-details/question-details.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { PipeModule } from '../../../../pipes/pipe.module';
import { IQuestionService } from '../../../../services/interfaces/question-service.interface';
import { QUESTION_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { RouterModule } from '@angular/router';
import { ServicesModule } from '../../../../services/services.module';
import { DialogComponent } from '../../../shared/dialog/dialog.component';

@Component({
  selector: 'app-question-list',
  standalone: true,
  imports: [
    FontAwesomeModule,
    RouterModule,
    CommonModule,
    QuestionDetailsComponent,
    PipeModule,
    ServicesModule,
    DialogComponent,
  ],
  templateUrl: './question-list.component.html',
  styleUrl: './question-list.component.css',
})
export class QuestionListComponent {
  public QuestionType = QuestionType;
  public faEdit = faEdit;
  public faTrashCan = faTrashCan;
  public faPlus = faPlus;

  public title: string = 'Question List';
  public selectedId: string = '';
  public isShowDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public questions: any[] = [];

  /**
   *
   */
  constructor(
    @Inject(QUESTION_SERVICE_INJECTOR)
    private questionService: IQuestionService
  ) {}

  ngOnInit(): void {
    this.getData();
  }

  private getData() {
    this.questionService.getAll().subscribe((data) => {
      this.questions = data;
    });
  }

  public delete(id: string): void {
    this.questionService.delete(id).subscribe((data) => {
      if (data) {
        this.questions = this.questions.filter(
          (question) => question.id !== id
        );
      } else {
        // Show error message
        this.dialogTitle = 'Error';
        this.dialogMessage = 'Error while saving data';
        this.isShowDialog = true;
      }
    });
  }

  public edit(id: string): void {
    this.onCancelDetails();
    this.selectedId = id;
    this.isShowDetails = true;
  }

  public add(): void {
    this.onCancelDetails();
    this.selectedId = '';
    this.isShowDetails = true;
  }

  /**
   * on cancel details
   */
  public onCancelDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
  }

  /**
   * on save details
   */
  public onSaveDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
    this.getData();
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
