import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faArrowRotateLeft, faSave } from '@fortawesome/free-solid-svg-icons';
import { IQuestionService } from '../../../../../services/interfaces/question-service.interface';
import { QUESTION_SERVICE_INJECTOR } from '../../../../../constants/injection-token.constant';
import { DialogComponent } from '../../../../shared/dialog/dialog.component';

@Component({
  selector: 'app-answer-details',
  standalone: true,
  imports: [
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    DialogComponent,
  ],
  templateUrl: './answer-details.component.html',
  styleUrl: './answer-details.component.css',
})
export class AnswerDetailsComponent {
  private _selectedId!: string;
  @Input() public set selectedId(data: string) {
    this._selectedId = data;

    if (data) {
      this.getData();
    } else {
      this.formGroup?.reset();
    }
  }

  public get selectedId(): string {
    return this._selectedId;
  }

  @Input() public selectedQuestionId!: string;
  @Output() cancelForm: EventEmitter<any> = new EventEmitter();
  @Output() saveForm: EventEmitter<any> = new EventEmitter();

  public faSave = faSave;
  public faArrowRotateLeft = faArrowRotateLeft;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  constructor(
    @Inject(QUESTION_SERVICE_INJECTOR) private questionService: IQuestionService
  ) {}

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      questionId: new FormControl(this.selectedQuestionId),
      content: new FormControl('', [Validators.required, Validators.maxLength(500), Validators.minLength(1)]),
      isCorrect: new FormControl(false, [Validators.required]),
      isActive: new FormControl(false, [Validators.required]),
    });
  }

  private getData() {
    this.questionService.getAnswerById(this.selectedId).subscribe((data) => {
      if (data) {
        this.formGroup.patchValue(data);
      } else {
        // show error
        this.dialogTitle = 'Get Answer Error';
        this.dialogMessage = 'Error while getting data';
        this.isShowDialog = true;
      }
    });
  }

  /**
   * cancel form
   */
  public cancel() {
    this.cancelForm.emit(true);
  }

  /**
   * save form
   */

  public save() {
    if (this.formGroup.valid) {
      if (this.selectedId === '') {
        this.questionService
          .addAnswerToQuestion(this.formGroup.value)
          .subscribe((data) => {
            if (data) {
              this.saveForm.emit(true);
            } else {
              // show error
              this.dialogTitle = 'Create Answer Error';
              this.dialogMessage = 'Error while saving data';
              this.isShowDialog = true;
            }
          });
      } else {
        this.formGroup.addControl('id', new FormControl(this.selectedId));
        this.questionService
          .updateAnswerToQuestion(this.formGroup.value)
          .subscribe((data) => {
            if (data) {
              this.saveForm.emit(true);
            } else {
              // show error
              this.dialogTitle = 'Update Answer Error';
              this.dialogMessage = 'Error while saving data';
              this.isShowDialog = true;
            }
          });
      }
    } else {
      // show error
      this.dialogTitle = 'Validation Error';
      this.dialogMessage = 'Please fill all required fields';
      this.isShowDialog = true;
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
