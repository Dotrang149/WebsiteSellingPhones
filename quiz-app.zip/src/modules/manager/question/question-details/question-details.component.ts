import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  faArrowRotateLeft,
  faEdit,
  faPlus,
  faSave,
  faTrashCan,
} from '@fortawesome/free-solid-svg-icons';
import { QuestionType } from '../../../../enums/question-type.enum';
import { CommonModule } from '@angular/common';
import { AnswerDetailsComponent } from './answer-details/answer-details.component';
import { QUESTION_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { IQuestionService } from '../../../../services/interfaces/question-service.interface';
import { AnswerViewModel } from '../../../../view-models/question/answer.view-model';

@Component({
  selector: 'app-question-details',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    FontAwesomeModule,
    FormsModule,
    CommonModule,
    AnswerDetailsComponent,
  ],
  templateUrl: './question-details.component.html',
  styleUrl: './question-details.component.css',
})
export class QuestionDetailsComponent {
  private _selectedId!: string;
  @Input() public set selectedId(data: string) {
    this._selectedId = data;

    if (data) {
      this.getData();
    } else {
      this.formGroup?.reset();
    }
  }

  public get selectedId(): string {
    return this._selectedId;
  }

  @Output() cancelForm: EventEmitter<any> = new EventEmitter();
  @Output() saveForm: EventEmitter<any> = new EventEmitter();

  public faEdit = faEdit;
  public faTrashCan = faTrashCan;
  public faPlus = faPlus;
  public faSave = faSave;
  public faArrowRotateLeft = faArrowRotateLeft;

  public questionModel: any = {};
  public isShowAnswerList: boolean = false;
  public isShowAnswerDetails: boolean = false;
  public selectedAnswerId: string = '';

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  // Convert question enum to array
  public questionTypes!: any[];

  public answers: AnswerViewModel[] = [];

  constructor(
    @Inject(QUESTION_SERVICE_INJECTOR) private questionService: IQuestionService
  ) {}

  ngOnInit(): void {
    this.questionTypes = Object.values(QuestionType)
      .map((key: any) => {
        if (typeof key === 'number') {
          return { id: key, name: QuestionType[key] };
        }
        return null;
      })
      .filter((item: any) => item !== null);

    this.formGroup = new FormGroup({
      content: new FormControl(''),
      questionType: new FormControl(''),
      isActive: new FormControl(''),
    });
  }

  private getData() {
    this.questionService.getById(this.selectedId).subscribe((data) => {
      this.formGroup.patchValue(data);
    });
  }

  /**
   * get answers
   */
  public getAnswers() {
    this.questionService
      .getAnswersByQuestionId(this.selectedId)
      .subscribe((data: any) => {
        if (data) {
          this.answers = data;
        } else {
          // show error
          this.dialogTitle = 'Get Answers Error';
          this.dialogMessage = 'Error while getting data';
          this.isShowDialog = true;
        }
      });
  }

  /**
   * cancel form
   */
  public cancel() {
    this.cancelForm.emit(true);
  }

  /**
   * save form
   */

  public save() {
    if (this.formGroup.valid) {
      if (this.selectedId === '') {
        this.questionService.addAnswerToQuestion(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Create Role Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      } else {
        this.formGroup.addControl('id', new FormControl(this.selectedId));
        this.questionService.updateAnswerToQuestion(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Update Role Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      }
    } else {
      // show error
      this.dialogTitle = 'Validation Error';
      this.dialogMessage = 'Please fill all required fields';
      this.isShowDialog = true;
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }

  /**
   * add answer form
   */

  public showAnswer() {
    this.isShowAnswerList = true;
    this.getAnswers();
  }

  public edit(id: string): void {
    this.selectedId = id;
    this.isShowAnswerList = true;
  }

  public deleteAnswer(id: string): void {
    this.questionService.deleteAnswer(id, this.selectedId).subscribe((data) => {
      if (data) {
        this.answers = this.answers.filter((answer) => answer.id !== id);
      } else {
        // Show error message
        this.dialogTitle = 'Error';
        this.dialogMessage = 'Error while saving data';
        this.isShowDialog = true;
      }
    });
  }

  public editAnswer(id: string): void {
    this.onCancelDetails();
    this.selectedAnswerId = id;
    this.isShowAnswerDetails = true;
  }

  public cancelAnswerList(): void {
    this.selectedAnswerId = '';
    this.isShowAnswerList = false;
  }

  public addAnswer(): void {
    this.selectedAnswerId = '';
    this.isShowAnswerDetails = true;
  }

  public onCancelDetails(): void {
    this.selectedId = '';
    this.isShowAnswerDetails = false;
  }

  public onSaveDetails(): void {
    this.getAnswers();
    this.selectedId = '';
    this.isShowAnswerDetails = false;
  }
}
