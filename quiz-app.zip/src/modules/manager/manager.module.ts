import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { QuizListComponent } from './quiz/quiz-list/quiz-list.component';
import { QuestionListComponent } from './question/question-list/question-list.component';
import { UserListComponent } from './user/user-list/user-list.component';
import { RoleListComponent } from './role/role-list/role-list.component';

export const routes: Routes = [
  {
    path: 'quiz',
    component: QuizListComponent
  },
  {
    path: 'question',
    component: QuestionListComponent,
  },
  {
    path: 'user',
    component: UserListComponent,
  },
  {
    path: 'role',
    component: RoleListComponent,
  },
  {
    path: '**',
    redirectTo: 'quiz',
    pathMatch: 'full',
  },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagerModule {}
