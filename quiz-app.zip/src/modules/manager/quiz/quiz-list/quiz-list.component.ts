import { CommonModule } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faEdit, faPlus, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { QuizDetailsComponent } from '../quiz-details/quiz-details.component';
import { PipeModule } from '../../../../pipes/pipe.module';
import { QUIZ_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { IQuizService } from '../../../../services/interfaces/quiz-service.interface';
import { ServicesModule } from '../../../../services/services.module';
import { DialogComponent } from '../../../shared/dialog/dialog.component';

@Component({
  selector: 'app-quiz-list',
  standalone: true,
  imports: [
    FontAwesomeModule,
    RouterModule,
    CommonModule,
    QuizDetailsComponent,
    PipeModule,
    ServicesModule,
    DialogComponent,
  ],
  templateUrl: './quiz-list.component.html',
  styleUrl: './quiz-list.component.css',
})
export class QuizListComponent implements OnInit {
  public faEdit = faEdit;
  public faTrashCan = faTrashCan;
  public faPlus = faPlus;

  public title: string = 'Quiz List';
  public selectedId: string = '';
  public isShowDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  /**
   *
   */
  constructor(
    @Inject(QUIZ_SERVICE_INJECTOR) private quizService: IQuizService
  ) {}

  public quizzes: any[] = [];

  ngOnInit(): void {
    this.getData();
  }

  private getData() {
    // Get data from service
    this.quizService.getAll().subscribe((data) => {
      this.quizzes = data;
    });
  }

  public delete(id: string): void {
    this.quizService.delete(id).subscribe((data) => {
      if (data) {
        this.quizzes = this.quizzes.filter((quiz) => quiz.id !== id);
      } else {
        // Show error message
        this.dialogTitle = 'Error';
        this.dialogMessage = 'Error while saving data';
        this.isShowDialog = true;
      }
    });
  }

  public edit(id: string): void {
    this.onCancelDetails();
    this.selectedId = id;
    this.isShowDetails = true;
  }

  public add(): void {
    this.onCancelDetails();
    this.selectedId = '';
    this.isShowDetails = true;
  }

  /**
   * on cancel details
   */
  public onCancelDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
  }

  /**
   * on save details
   */
  public onSaveDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
    this.getData();
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
