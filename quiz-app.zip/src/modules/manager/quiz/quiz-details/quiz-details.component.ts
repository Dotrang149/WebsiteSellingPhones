import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  faArrowRotateLeft,
  faEdit,
  faPlus,
  faSave,
  faTrashCan,
} from '@fortawesome/free-solid-svg-icons';
import { QuestionType } from '../../../../enums/question-type.enum';
import { QuizQuestionDetailsComponent } from './quiz-question-details/quiz-question-details.component';
import { PipeModule } from '../../../../pipes/pipe.module';
import { CommonModule } from '@angular/common';
import { IQuizService } from '../../../../services/interfaces/quiz-service.interface';
import {
  QUESTION_SERVICE_INJECTOR,
  QUIZ_SERVICE_INJECTOR,
} from '../../../../constants/injection-token.constant';
import { DialogComponent } from '../../../shared/dialog/dialog.component';
import { IQuestionService } from '../../../../services/interfaces/question-service.interface';

@Component({
  selector: 'app-quiz-details',
  standalone: true,
  imports: [
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    QuizQuestionDetailsComponent,
    PipeModule,
    CommonModule,
    DialogComponent,
  ],
  templateUrl: './quiz-details.component.html',
  styleUrl: './quiz-details.component.css',
})
export class QuizDetailsComponent implements OnInit {
  private _selectedId!: string;
  @Input() public set selectedId(data: string) {
    this._selectedId = data;
    this.isShowQuizQuestionDetails = false;
    if (data) {
      this.getData();
    } else {
      this.formGroup?.reset();
    }
  }

  public get selectedId(): string {
    return this._selectedId;
  }

  @Output() cancelForm: EventEmitter<any> = new EventEmitter();
  @Output() saveForm: EventEmitter<any> = new EventEmitter();

  public QuestionType = QuestionType;
  public faSave = faSave;
  public faPlus = faPlus;
  public faTrashCan = faTrashCan;
  public faEdit = faEdit;
  public faArrowRotateLeft = faArrowRotateLeft;

  public isShowQuizQuestionList: boolean = false;
  public isShowQuizQuestionDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  public questions: any[] = [];

  constructor(
    @Inject(QUIZ_SERVICE_INJECTOR) private quizService: IQuizService,
    @Inject(QUESTION_SERVICE_INJECTOR)
    private questionService: IQuestionService
  ) {
    this.isShowQuizQuestionDetails = false;
  }

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      title: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      description: new FormControl('', [
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      duration: new FormControl(1, [
        Validators.required,
        Validators.pattern('^[0-9]*$'),
        Validators.min(1),
      ]),
      thumbnailUrl: new FormControl(''),
      isActive: new FormControl('', [Validators.required]),
    });
  }

  private getData() {
    this.quizService.getById(this.selectedId).subscribe((data) => {
      this.formGroup.patchValue(data);
    });
  }

  private getQuestions() {
    this.questionService
      .getQuestionsByQuizId(this.selectedId)
      .subscribe((data) => {
        this.questions = data;
      });
  }

  /**
   * cancel form
   */
  public cancel() {
    this.cancelForm.emit(true);
  }

  /**
   * save form
   */

  public save() {
    if (this.formGroup.valid) {
      if (this.selectedId === '') {
        this.quizService.create(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Create Quiz Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      } else {
        this.formGroup.addControl('id', new FormControl(this.selectedId));
        this.quizService.update(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Update Quiz Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      }
    } else {
      // show error
      this.dialogTitle = 'Validation Error';
      this.dialogMessage = 'Please fill all required fields';
      this.isShowDialog = true;
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }

  public showQuizQuestions() {
    this.isShowQuizQuestionList = true;
    this.getQuestions();
  }

  public deleteQuizQuestion(id: string): void {
    this.quizService
      .deleteQuestionFromQuiz(this.selectedId, id)
      .subscribe((data) => {
        if (data) {
          this.questions = this.questions.filter(
            (question) => question.id !== id
          );
        } else {
          // Show error message
          this.dialogTitle = 'Error';
          this.dialogMessage = 'Error while saving data';
          this.isShowDialog = true;
        }
      });
  }

  public cancelQuizQuestionList(): void {
    this.isShowQuizQuestionList = false;
  }

  public addQuizQuestion(): void {
    this.isShowQuizQuestionDetails = true;
  }

  /**
   * on cancel details
   */
  public onCancelDetails() {
    this.isShowQuizQuestionDetails = false;
  }

  /**
   * on save details
   */
  public onSaveDetails() {
    this.isShowQuizQuestionDetails = false;
    this.getQuestions();
  }
}
