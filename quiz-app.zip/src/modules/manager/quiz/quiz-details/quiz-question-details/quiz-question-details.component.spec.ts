import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuizQuestionDetailsComponent } from './quiz-question-details.component';

describe('QuizQuestionDetailsComponent', () => {
  let component: QuizQuestionDetailsComponent;
  let fixture: ComponentFixture<QuizQuestionDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuizQuestionDetailsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(QuizQuestionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
