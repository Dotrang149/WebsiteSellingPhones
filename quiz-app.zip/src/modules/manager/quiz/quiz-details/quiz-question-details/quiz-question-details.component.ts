import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { faArrowRotateLeft, faSave } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { CommonModule } from '@angular/common';
import {
  QUESTION_SERVICE_INJECTOR,
  QUIZ_SERVICE_INJECTOR,
} from '../../../../../constants/injection-token.constant';
import { IQuestionService } from '../../../../../services/interfaces/question-service.interface';
import { IQuizService } from '../../../../../services/interfaces/quiz-service.interface';
import { DialogComponent } from '../../../../shared/dialog/dialog.component';

@Component({
  selector: 'app-quiz-question-details',
  standalone: true,
  imports: [
    FontAwesomeModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    DialogComponent,
  ],
  templateUrl: './quiz-question-details.component.html',
  styleUrl: './quiz-question-details.component.css',
})
export class QuizQuestionDetailsComponent {
  @Input() public selectedId!: string;
  @Output() cancelForm: EventEmitter<any> = new EventEmitter();
  @Output() saveForm: EventEmitter<any> = new EventEmitter();

  public faSave = faSave;
  public faArrowRotateLeft = faArrowRotateLeft;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  public questions: any[] = [];

  constructor(
    @Inject(QUESTION_SERVICE_INJECTOR)
    private questionService: IQuestionService,
    @Inject(QUIZ_SERVICE_INJECTOR) private quizService: IQuizService
  ) {}

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      questionId: new FormControl('', [Validators.required]),
      quizId: new FormControl(this.selectedId, [Validators.required]),
      order: new FormControl(1, [Validators.required, Validators.min(1)]),
    });

    this.getData();
  }

  /**
   * get data
   */
  public getData() {
    this.questionService.getAll().subscribe((data) => {
      this.questions = data;
    });
  }

  /**
   * cancel form
   */
  public cancel() {
    this.cancelForm.emit(true);
  }

  /**
   * save form
   */

  public save() {
    if (this.formGroup.valid) {
      this.formGroup.patchValue({ quizId: this.selectedId });
      this.quizService
        .addQuestionToQuiz(this.formGroup.value)
        .subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Create Quiz Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
    } else {
      // show error
      this.dialogTitle = 'Validation Error';
      this.dialogMessage = 'Please fill all required fields';
      this.isShowDialog = true;
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
