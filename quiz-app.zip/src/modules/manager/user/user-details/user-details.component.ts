import { CommonModule, formatDate } from '@angular/common';
import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faArrowRotateLeft, faSave } from '@fortawesome/free-solid-svg-icons';
import { IUserService } from '../../../../services/interfaces/user-service.interface';
import { USER_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { DialogComponent } from '../../../shared/dialog/dialog.component';
import { ServicesModule } from '../../../../services/services.module';

@Component({
  selector: 'app-user-details',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    FontAwesomeModule,
    FormsModule,
    CommonModule,
    DialogComponent,
    ServicesModule,
  ],
  templateUrl: './user-details.component.html',
  styleUrl: './user-details.component.css',
})
export class UserDetailsComponent implements OnInit {
  private _selectedId!: string;
  @Input() public set selectedId(data: string) {
    this._selectedId = data;

    if (data) {
      this.getData();
    } else {
      this.formGroup?.reset();
    }
  }

  public get selectedId(): string {
    return this._selectedId;
  }

  @Output() cancelForm: EventEmitter<any> = new EventEmitter();
  @Output() saveForm: EventEmitter<any> = new EventEmitter();

  public faSave = faSave;
  public faArrowRotateLeft = faArrowRotateLeft;

  public selectedQuizQuestionId: string = '';
  public isShowQuizQuestionList: boolean = false;
  public isShowQuizQuestionDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public formGroup!: FormGroup;

  constructor(
    @Inject(USER_SERVICE_INJECTOR) private userService: IUserService
  ) {}

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      firstName: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      lastName: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      email: new FormControl('', [
        Validators.required,
        Validators.email,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      userName: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      password: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(8),
      ]),
      confirmPassword: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(8),
      ]),
      phoneNumber: new FormControl('', [
        Validators.required,
        Validators.maxLength(50),
        Validators.minLength(3),
      ]),
      dateOfBirth: new FormControl(formatDate(Date.now(), 'yyyy-MM-dd', 'en'), [
        Validators.required,
      ]),
      isActive: new FormControl('', [Validators.required]),
    });

    if (this.selectedId) {
      this.formGroup.removeControl('password');
      this.formGroup.removeControl('confirmPassword');
    }
  }

  private getData() {
    this.userService.getById(this.selectedId).subscribe((data) => {
      if (data) {
        this.formGroup.reset();
        this.formGroup.patchValue(data);
        // Set date of birth
        this.formGroup
          .get('dateOfBirth')
          ?.setValue(formatDate(data.dateOfBirth, 'yyyy-MM-dd', 'en'));
      } else {
        // show error
        this.dialogTitle = 'Get User Error';
        this.dialogMessage = 'Error while getting data';
        this.isShowDialog = true;
      }
    });
  }

  /**
   * cancel form
   */
  public cancel() {
    this.cancelForm.emit(true);
  }

  /**
   * save form
   */

  public save() {
    if (this.formGroup.valid) {
      if (this.selectedId === '') {
        this.userService.create(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Create User Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      } else {
        this.formGroup.addControl('id', new FormControl(this.selectedId));
        this.userService.update(this.formGroup.value).subscribe((data) => {
          if (data) {
            this.saveForm.emit(true);
          } else {
            // show error
            this.dialogTitle = 'Update User Error';
            this.dialogMessage = 'Error while saving data';
            this.isShowDialog = true;
          }
        });
      }
    } else {
      // show error
      this.dialogTitle = 'Validation Error';
      this.dialogMessage = 'Please fill all required fields';
      this.isShowDialog = true;
    }
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
