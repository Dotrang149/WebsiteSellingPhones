import { Component, Inject } from '@angular/core';
import { UserDetailsComponent } from '../user-details/user-details.component';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faEdit, faPlus, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { USER_SERVICE_INJECTOR } from '../../../../constants/injection-token.constant';
import { IUserService } from '../../../../services/interfaces/user-service.interface';
import { DialogComponent } from '../../../shared/dialog/dialog.component';
import { ServicesModule } from '../../../../services/services.module';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [
    CommonModule,
    UserDetailsComponent,
    FontAwesomeModule,
    ServicesModule,
    DialogComponent,
  ],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css',
})
export class UserListComponent {
  public faEdit = faEdit;
  public faTrashCan = faTrashCan;
  public faPlus = faPlus;

  public title: string = 'User List';
  public selectedId: string = '';
  public isShowDetails: boolean = false;

  public dialogTitle: string = '';
  public dialogMessage: string = '';
  public isShowDialog: boolean = false;

  public users: any[] = [];

  constructor(
    @Inject(USER_SERVICE_INJECTOR) private userService: IUserService
  ) {}

  ngOnInit(): void {
    this.getData();
  }

  private getData() {
    // Get data from service
    this.userService.getAll().subscribe((data) => {
      this.users = data;
    });
  }

  public delete(id: string): void {
    this.userService.delete(id).subscribe((data) => {
      if (data) {
        this.getData();
      } else {
        // Show error message
        // show error
        this.dialogTitle = 'Error';
        this.dialogMessage = 'Error while saving data';
        this.isShowDialog = true;
      }
    });
  }

  public edit(id: string): void {
    this.onCancelDetails();
    this.selectedId = id;
    this.isShowDetails = true;
  }

  public add(): void {
    this.onCancelDetails();
    this.selectedId = '';
    this.isShowDetails = true;
  }

  /**
   * on cancel details
   */
  public onCancelDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
  }

  /**
   * on save details
   */
  public onSaveDetails() {
    this.isShowDetails = false;
    this.selectedId = '';
    this.getData();
  }

  /**
   * on close dialog
   */

  public onCloseDialog() {
    this.isShowDialog = false;
  }
}
