import { UpperCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { faEnvelope, faHome, faPhone } from '@fortawesome/free-solid-svg-icons';
import {
  FormControl,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {
  faFacebook,
  faLinkedin,
  faTiktok,
  faYoutube,
} from '@fortawesome/free-brands-svg-icons';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, UpperCasePipe, FontAwesomeModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css',
})
export class ContactComponent implements OnInit {
  public contactForm: FormGroup;
  public nameControl!: FormControl;
  public emailControl!: FormControl;
  public messageControl!: FormControl;

  public faEnvelope = faEnvelope;
  public faPhone = faPhone;
  public faHome = faHome;

  public faFacebook = faFacebook;
  public faTikTok = faTiktok;
  public faYoutube = faYoutube;
  public faLinkedin = faLinkedin;

  constructor() {
    this.contactForm = new FormGroup({});
  }

  ngOnInit(): void {
    this.nameControl = new FormControl('');
    this.emailControl = new FormControl('');
    this.messageControl = new FormControl('');

    this.contactForm.addControl('name', this.nameControl);
    this.contactForm.addControl('email', this.emailControl);
    this.contactForm.addControl('message', this.messageControl);
  }

  public onSubmit(): void {
    console.log('Contact form value: ', this.contactForm.value);
  }
}
