import { CommonModule } from '@angular/common';
import { Component, Inject, Input, OnInit } from '@angular/core';
import { PipeModule } from '../../../pipes/pipe.module';
import { IQuizService } from '../../../services/interfaces/quiz-service.interface';
import {
  AUTH_SERVICE_INJECTOR,
  QUIZ_SERVICE_INJECTOR,
} from '../../../constants/injection-token.constant';
import { IAuthService } from '../../../services/interfaces/auth-service.interface';
import { UserViewModel } from '../../../view-models/user/user.view-model';
import { Router } from '@angular/router';
import { PrepareQuizViewModel } from '../../../view-models/quiz/prepare-quiz.view-model';

@Component({
  selector: 'app-quiz-card',
  standalone: true,
  imports: [CommonModule, PipeModule],
  templateUrl: './quiz-card.component.html',
  styleUrl: './quiz-card.component.css',
})
export class QuizCardComponent implements OnInit {
  public title: string = 'Quiz Details';
  @Input() public quiz: any;
  private currentUser: UserViewModel | undefined;

  constructor(
    @Inject(QUIZ_SERVICE_INJECTOR) private quizService: IQuizService,
    @Inject(AUTH_SERVICE_INJECTOR) private authService: IAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.currentUser = this.authService.getCurrentUser();
  }

  public prepareQuiz(quizId: string): void {
    if (this.currentUser) {
      const data: PrepareQuizViewModel = {
        quizId: quizId,
        userId: this.currentUser.id,
        quizCode: this.quiz.quizCode,
      };
      this.quizService.prepareQuiz(data).subscribe((res: any) => {
        // Redirect to start quiz page and pass res to the page
        this.router.navigateByUrl('/start-quiz', { state: { data: res } });
      });
    } else{
      this.router.navigateByUrl('/auth/login');
    }
  }
}
