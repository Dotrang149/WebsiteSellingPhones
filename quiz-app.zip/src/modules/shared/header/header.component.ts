import { CommonModule, UpperCasePipe } from '@angular/common';
import { Component, Inject, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { AUTH_SERVICE_INJECTOR } from '../../../constants/injection-token.constant';
import { IAuthService } from '../../../services/interfaces/auth-service.interface';
import { UserViewModel } from '../../../view-models/user/user.view-model';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [UpperCasePipe, RouterModule, CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent implements OnInit {
  public logoText: string = 'Quizzes';
  public isAuthenticated: boolean = false;
  public isManager: boolean = false;
  public userInformation: UserViewModel | undefined;

  public constructor(
    @Inject(AUTH_SERVICE_INJECTOR) private authService: IAuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isAuthenticated = this.authService.isAuthenticated();
    this.isManager = this.authService.isManager();
    this.userInformation = this.authService.getCurrentUser();
  }

  public logout(): void {
    this.authService.logout();
    this.isAuthenticated = false;

    // Redirect to login page
    window.location.href = '/';
  }

  public toggleProfileMenu(): void {
    const profileMenu = document.getElementById('profile-menu');
    if (profileMenu) {
      profileMenu.classList.toggle('show');
    }
  }

  public toggleMenu(): void {
    const menu = document.getElementById('menu');
    if (menu) {
      menu.classList.toggle('show');
    }
  }
}
