import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-dialog',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dialog.component.html',
  styleUrl: './dialog.component.css'
})
export class DialogComponent {

  @Input("title") public title: string = 'Dialog';
  @Input("message") public message: string = 'Message';
  @Input("showCancel") public showCancel: boolean = true;
  @Input("showOk") public showOk: boolean = true;
  @Input("okText") public okText: string = 'Ok';
  @Output() public close: EventEmitter<any> = new EventEmitter();
  @Output() public ok: EventEmitter<any> = new EventEmitter();

  constructor() { }

  public onOk() {
    // Close dialog
    this.ok.emit();
  }

  public onCancel() {
    // Close dialog
    this.close.emit();
  }
}
