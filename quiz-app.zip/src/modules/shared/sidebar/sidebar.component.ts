import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faEdit, faList, faPlus, faQ, faQuestion, faSquareCaretLeft, faUser, faUserCheck, faUserShield } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterModule, FontAwesomeModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css',
})
export class SidebarComponent {
  public title: string = 'Menu';

  public faSquareCaretLeft = faSquareCaretLeft;
  public faList = faList;
  public faUser = faUser;
  public faQuestion = faQuestion;
  public faQ = faQ;
  public faUserShield = faUserShield;
  public faEdit = faEdit;
  public faPlus = faPlus;

  public toggleMenu() {
    console.log('toggle menu');
  }
}
