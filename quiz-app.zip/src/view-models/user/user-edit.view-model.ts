export class UserEditViewModel {
  public id!: string;

  public firstName!: string;

  public lastName!: string;

  public email!: string;

  public username!: string;

  public password!: string;

  public confirmPassword!: string;

  public dateOfBirth!: Date;

  public phoneNumber!: string;

  public isActive: boolean = false;
}
