export class UserViewModel {
  public id!: string;

  public firstName!: string;

  public lastName!: string;

  public displayName!: string;

  public email!: string;

  public username!: string;

  public phoneNumber!: string;

  public dateOfBirth!: string;

  public avatar!: string;

  public isActive: boolean = false;

  public roles: string[] = [];
}
