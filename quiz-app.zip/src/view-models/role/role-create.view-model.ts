export class RoleCreateViewModel {
  public name!: string;

  public description!: string;

  public isActive: boolean = false;
}
