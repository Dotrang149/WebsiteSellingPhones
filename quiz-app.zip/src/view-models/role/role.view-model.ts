export class RoleViewModel {
  public id!: string;

  public name!: string;

  public description!: string;

  public isActive: boolean = false;
}
