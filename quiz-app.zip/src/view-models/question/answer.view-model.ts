export class AnswerViewModel {
  public id!: string;

  public content!: string;

  public isCorrect!: boolean;

  public isActive: boolean = false;

  public questionId!: string;
}
