import { QuestionType } from '../../enums/question-type.enum';

export class QuestionViewModel {
  public id!: string;

  public content!: string;

  public questionType!: QuestionType;

  public isActive: boolean = false;
}
