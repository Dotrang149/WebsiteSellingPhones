export class AnswerCreateViewModel {
  public content!: string;

  public isCorrect!: boolean;

  public isActive: boolean = true;

  public questionId!: string;
}
