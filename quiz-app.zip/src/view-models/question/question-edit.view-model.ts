import { QuestionType } from '../../enums/question-type.enum';

export class QuestionEditViewModel {
  public id!: string;

  public content!: string;

  public questionType!: QuestionType;

  public isActive: boolean = false;
}
