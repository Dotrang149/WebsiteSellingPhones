export class LoginViewModel {
  public username!: string;

  public password!: string;
}
