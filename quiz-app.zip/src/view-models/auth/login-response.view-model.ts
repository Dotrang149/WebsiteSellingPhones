export class LoginResponseViewModel {
  public userInformation!: string;

  public token!: string;

  public expires!: Date;
}
