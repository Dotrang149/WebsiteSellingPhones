export class QuizCreateViewModel {
  public title!: string;

  public description!: string;

  public duration!: number;

  public isActive: boolean = false;
}
