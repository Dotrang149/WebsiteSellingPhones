import { QuestionForTestViewModel } from "./question-for-tes.view-model";

export class QuizForTestViewModel {
  public id!: string;

  public title!: string;

  public description!: string;

  public duration!: number;

  public quizCode!: string;

  public startTime!: Date;

  public questions!: QuestionForTestViewModel[];
}
