export class QuizQuestionCreateViewModel {
  public quizId!: string;

  public questionId!: string;
}
