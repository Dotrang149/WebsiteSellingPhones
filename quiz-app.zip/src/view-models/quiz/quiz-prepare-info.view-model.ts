import { UserViewModel } from "../user/user.view-model";

export class QuizPrepareInfoViewModel {
  public id!: string;

  public title!: string;

  public description!: string;

  public duration!: number;

  public thumbnailUrl!: string;

  public quizCode!: string;

  public user!: UserViewModel;
}
