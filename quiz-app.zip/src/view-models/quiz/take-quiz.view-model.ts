export class TakeQuizViewModel {
  public quizId!: string;

  public userId!: string;

  public quizCode!: string;
}
