export class QuizSubmissionViewModel {
  public quizId!: string;

  public userId!: string;

  public quizCode!: string;

  public answers!: UserAnswerSubmissionViewModel[];
}

export class UserAnswerSubmissionViewModel {
  public questionId!: string;

  public answerId!: string;
}
