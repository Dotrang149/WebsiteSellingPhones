import { QuestionType } from "../../enums/question-type.enum";

export class QuestionForTestViewModel {
  public id!: string;

  public content!: string;

  public questionType!: QuestionType;

  public answers!: AnswerForTestViewModel[];
}

export class AnswerForTestViewModel {
  public id!: string;

  public content!: string;
}
