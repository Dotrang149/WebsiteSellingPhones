export class PrepareQuizViewModel {
  public userId!: string;

  public quizId!: string;

  public quizCode!: string;
}
