export enum QuestionType {
  MultipleChoice,
  SingleChoice,
  TrueFalse,
  FillInTheBlanks,
  ShortAnswer,
  LongAnswer,
}
