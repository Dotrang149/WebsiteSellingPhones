import { InjectionToken } from '@angular/core';
import { IUserService } from '../services/interfaces/user-service.interface';
import { IRoleService } from '../services/interfaces/role-service.interface';
import { IQuizService } from '../services/interfaces/quiz-service.interface';
import { IQuestionService } from '../services/interfaces/question-service.interface';
import { IAuthService } from '../services/interfaces/auth-service.interface';

export const AUTH_SERVICE_INJECTOR = new InjectionToken<IAuthService>(
  'AUTH_SERVICE_INJECTOR'
);

export const USER_SERVICE_INJECTOR = new InjectionToken<IUserService>(
  'USER_SERVICE_INJECTOR'
);

export const ROLE_SERVICE_INJECTOR = new InjectionToken<IRoleService>(
  'ROLE_SERVICE_INJECTOR'
);

export const QUIZ_SERVICE_INJECTOR = new InjectionToken<IQuizService>(
  'QUIZ_SERVICE_INJECTOR'
);

export const QUESTION_SERVICE_INJECTOR = new InjectionToken<IQuestionService>(
  'QUESTION_SERVICE_INJECTOR'
);
